# 已完成完整后筛链的 OVA 四聚体样本

本表只收录已经完成最终 fail-closed 后筛的结果；未完成的候选不按缺失值算通过。

共 23 条记录：E151 Final20 的 20 条，以及 3 条单独完成样本。

## 批次级结果

| 批次 | 数量 | sequence | AF3 | ProLIF | Protenix-v2 | 化学计量 | Rosetta | OpenDDE | 全部 required |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| E151 Final20 | 20 | 0/20 | 0/20 | 16/20 | 0/20 | 20/20 | 0/20 | 20/20 complete | 0/20 |
| AI-MULTIHIT-11 | 1 | 1/1 | 1/1 | 1/1 | 0/1 | 0/1 | 0/1 | 1/1 complete | 0/1 |
| OVA-C4-073 | 1 | 1/1 | 1/1 | 1/1 | 0/1 | 1/1 | 0/1 | 1/1 complete | 0/1 |
| c06 | 1 | 1/1 | 1/1 | 0/1 | 0/1 | 1/1 | 0/1 | 1/1 complete | 0/1 |

说明：E151 的 OpenDDE 已完成 10 seeds，但 0 条有可选代表结构；因此表中的 OpenDDE 列表示完成数，不表示通过数。

## E151 Final20 逐样本摘要

| 样本 | 突变/表面比例 | AF3均值/最低 | 零clash/C4 | ProLIF | Protenix均值/最低 | Rosetta SC/H-bond/unsat | OpenDDE均值/最高 | 失败 required |
|---|---:|---:|---:|---:|---:|---|---:|---|
| OVA-C4-IPTM80-20A | 20/0.750 | 0.847/0.830 | 12/25; 25/25 | 1 | 0.601/0.364 | 0.603/0.0/8.72 | 0.339/0.355 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21B | 21/0.714 | 0.841/0.820 | 8/25; 25/25 | 1 | 0.748/0.657 | 0.606/0.0/8.08 | 0.338/0.355 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-20D | 20/0.750 | 0.832/0.810 | 11/25; 25/25 | 1 | 0.395/0.378 | 0.653/2.0/12.91 | 0.348/0.353 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21C | 21/0.714 | 0.836/0.810 | 12/25; 25/25 | 0 | 0.406/0.371 | 0.631/1.0/7.53 | 0.379/0.382 | sequence;af3;prolif;protenix;rosetta |
| OVA-C4-IPTM80-21E | 21/0.714 | 0.831/0.810 | 19/25; 25/25 | 1 | 0.405/0.379 | 0.601/3.0/3.13 | 0.426/0.428 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-19K | 19/0.684 | 0.817/0.800 | 22/25; 24/25 | 1 | 0.788/0.744 | 0.554/0.0/11.09 | 0.572/0.581 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-19F | 19/0.684 | 0.824/0.810 | 20/25; 25/25 | 1 | 0.493/0.376 | 0.592/0.0/6.72 | 0.268/0.273 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-19L | 19/0.737 | 0.815/0.760 | 13/25; 25/25 | 1 | 0.429/0.339 | 0.556/1.0/7.46 | 0.342/0.368 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21H | 21/0.714 | 0.822/0.800 | 16/25; 25/25 | 1 | 0.381/0.347 | 0.646/2.0/13.55 | 0.360/0.381 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21G | 21/0.714 | 0.823/0.800 | 16/25; 25/25 | 1 | 0.343/0.309 | 0.430/1.0/7.90 | 0.338/0.349 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21I | 21/0.714 | 0.822/0.810 | 9/25; 25/25 | 1 | 0.582/0.313 | 0.689/1.0/7.73 | 0.291/0.301 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-19J | 19/0.737 | 0.822/0.800 | 15/25; 25/25 | 0 | 0.539/0.486 | 0.632/5.0/7.85 | 0.369/0.416 | sequence;af3;prolif;protenix;rosetta |
| OVA-C4-IPTM80-20N | 20/0.700 | 0.811/0.790 | 13/25; 25/25 | 1 | 0.634/0.492 | 0.588/2.0/4.49 | 0.355/0.367 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-19R | 19/0.737 | 0.809/0.790 | 17/25; 25/25 | 0 | 0.429/0.251 | 0.654/4.0/5.97 | 0.283/0.295 | sequence;af3;prolif;protenix;rosetta |
| OVA-C4-IPTM80-20O | 20/0.750 | 0.811/0.780 | 14/25; 25/25 | 1 | 0.537/0.497 | 0.551/4.0/11.17 | 0.346/0.372 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21M | 21/0.714 | 0.813/0.780 | 16/25; 25/25 | 1 | 0.391/0.377 | 0.670/2.0/10.64 | 0.339/0.344 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21P | 21/0.714 | 0.810/0.800 | 16/25; 24/25 | 0 | 0.541/0.408 | 0.545/2.0/9.04 | 0.406/0.493 | sequence;af3;prolif;protenix;rosetta |
| OVA-C4-IPTM80-20T | 20/0.700 | 0.806/0.790 | 4/25; 25/25 | 1 | 0.564/0.415 | 0.450/0.0/8.38 | 0.269/0.363 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-21S | 21/0.714 | 0.809/0.760 | 19/25; 25/25 | 1 | 0.703/0.590 | 0.586/1.0/8.04 | 0.346/0.408 | sequence;af3;protenix;rosetta |
| OVA-C4-IPTM80-22Q | 22/0.727 | 0.810/0.800 | 11/25; 25/25 | 1 | 0.477/0.262 | 0.614/1.0/7.12 | 0.356/0.383 | sequence;af3;protenix;rosetta |

## 三条单独完成样本

| 样本 | 突变 | AF3均值/最低 | AF3零clash | ProLIF | Protenix均值/最低 | 计量特异性 | Rosetta SC/H-bond/unsat | OpenDDE均值/最高 | 失败 required |
|---|---:|---:|---:|---|---:|---:|---|---:|---|
| ova_body_c4_multihit11_ms | 20 | 0.842/0.830 | 25/25 | 1 (7 non-VdW) | 0.695/0.518 | —; unique — | 0.678/0.0/9.77 | 0.269/0.332 | protenix;stoichiometry;rosetta;opendde |
| ova_body_c4_073_ms | 17 | 0.850/0.840 | 25/25 | 1 (6 non-VdW) | 0.677/0.385 | 0.362; unique 25 | 0.658/0.0/9.03 | 0.278/0.358 | protenix;rosetta;opendde |
| ova_body_c4_06_ms25_r04 | 19 | 0.850/0.830 | 25/25 | 0 (6 non-VdW) | 0.660/0.381 | 0.376; unique 25 | 0.641/0.0/12.87 | 0.412/0.444 | prolif;protenix;rosetta;opendde |

## 解释

- `COMPLETE_NO_ELIGIBLE_REP` 表示 OpenDDE 的 10 个 seed 都跑完了，但没有同时满足 ipTM>0.80 和几何条件的代表结构；不是任务缺失。
- Protenix-v2 的 `0/5 geometry-clean`、低均值/最低 ipTM 是这几条候选最一致的独立模型失败模式。
- Rosetta 虽常能得到零clash和保持C4拓扑，但弱界面氢键为0或埋藏未满足极性原子较高，因此不能晋级。

逐样本机器可读结果见 `COMPLETED_POSTSCREEN_RESULTS.tsv`；原始宽表仍保留在各实验目录。

### 原始来源

- `experiments/e151_final20_screen_v1/unified/final20_failclosed_screen.tsv`
- `experiments/e190_c4_multihit11_screen_v1/unified_current_after_opendde/final20_failclosed_screen.tsv`
- `experiments/e213_c4_073_screen_v1/unified_final/final20_failclosed_screen.tsv`
- `experiments/current_pending_v1_screen/ova_body_c4_06_ms25_r04/unified_final/final20_failclosed_screen.tsv`
